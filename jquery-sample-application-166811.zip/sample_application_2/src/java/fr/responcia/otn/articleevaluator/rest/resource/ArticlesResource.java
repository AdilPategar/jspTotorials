/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.responcia.otn.articleevaluator.rest.resource;

import fr.responcia.otn.articleevaluator.Article;
import java.util.Collection;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.persistence.EntityManager;
import fr.responcia.otn.articleevaluator.Vote;
import fr.responcia.otn.articleevaluator.Author;
import fr.responcia.otn.articleevaluator.rest.converter.ArticlesConverter;
import fr.responcia.otn.articleevaluator.rest.converter.ArticleConverter;
import javax.persistence.PersistenceContext;
import javax.ejb.Stateless;

/**
 *
 * @author julien
 */

@Path("/articles/")
@Stateless
public class ArticlesResource {
    @javax.ejb.EJB
    private ArticleResource articleResource;
    @Context
    protected UriInfo uriInfo;
    @PersistenceContext(unitName = "ArticleEvaluatorPU")
    protected EntityManager em;
  
    /** Creates a new instance of ArticlesResource */
    public ArticlesResource() {
    }

    /**
     * Get method for retrieving a collection of Article instance in XML format.
     *
     * @return an instance of ArticlesConverter
     */
    @GET
    @Produces({"application/xml", "application/json"})
    public ArticlesConverter get(@QueryParam("start")
                                 @DefaultValue("0")
    int start, @QueryParam("max")
               @DefaultValue("10")
    int max, @QueryParam("expandLevel")
             @DefaultValue("1")
    int expandLevel, @QueryParam("query")
                     @DefaultValue("SELECT e FROM Article e")
    String query) {
        return new ArticlesConverter(getEntities(start, max, query), uriInfo.getAbsolutePath(), expandLevel);
    }

    /**
     * Post method for creating an instance of Article using XML as the input format.
     *
     * @param data an ArticleConverter entity that is deserialized from an XML stream
     * @return an instance of ArticleConverter
     */
    @POST
    @Consumes({"application/xml", "application/json"})
    public Response post(ArticleConverter data) {
        Article entity = data.resolveEntity(em);
        createEntity(data.resolveEntity(em));
        return Response.created(uriInfo.getAbsolutePath().resolve(entity.getId() + "/")).build();
    }

    /**
     * Returns a dynamic instance of ArticleResource used for entity navigation.
     *
     * @return an instance of ArticleResource
     */
    @Path("{id}/")
    public ArticleResource getArticleResource(@PathParam("id")
    Long id) {
        articleResource.setId(id);
        articleResource.setEm(em);
        return articleResource;
    }

    /**
     * Returns all the entities associated with this resource.
     *
     * @return a collection of Article instances
     */
    protected Collection<Article> getEntities(int start, int max, String query) {
        return em.createQuery(query).setFirstResult(start).setMaxResults(max).getResultList();
    }

    /**
     * Persist the given entity.
     *
     * @param entity the entity to persist
     */
    protected void createEntity(Article entity) {
        entity.setId(null);
        em.persist(entity);
        for (Vote value : entity.getVotes()) {
            Article oldEntity = value.getArticle();
            value.setArticle(entity);
            if (oldEntity != null) {
                oldEntity.getVotes().remove(value);
            }
        }
        Author author = entity.getAuthor();
        if (author != null) {
            author.getArticles().add(entity);
        }
    }
}
