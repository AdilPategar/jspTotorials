/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.responcia.otn.articleevaluator;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 *
 * @author julien
 */
@Entity
public class Vote implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    private int stars;
    @ManyToOne
    private Article article;
    private String ip;

    /**
     * Get the value of ip
     *
     * @return the value of ip
     */
    public String getIp() {
        return ip;
    }

    /**
     * Set the value of ip
     *
     * @param ip new value of ip
     */
    public void setIp(String ip) {
        this.ip = ip;
    }

    /**
     * Get the value of article
     *
     * @return the value of article
     */
    public Article getArticle() {
        return article;
    }

    /**
     * Set the value of article
     *
     * @param article new value of article
     */
    public void setArticle(Article article) {
        this.article = article;
    }

    /**
     * Get the value of stars
     *
     * @return the value of stars
     */
    public int getStars() {
        return stars;
    }

    /**
     * Set the value of stars
     *
     * @param stars new value of stars
     */
    public void setStars(int stars) {
        this.stars = stars;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Vote)) {
            return false;
        }
        Vote other = (Vote) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "fr.responcia.otn.articleevaluator.Vote[id=" + id + "]";
    }

}
