/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.responcia.otn.articleevaluator.rest.resource;

import fr.responcia.otn.articleevaluator.Vote;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.QueryParam;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.WebApplicationException;
import javax.persistence.NoResultException;
import javax.persistence.EntityManager;
import fr.responcia.otn.articleevaluator.Article;
import fr.responcia.otn.articleevaluator.rest.converter.VoteConverter;
import javax.ejb.Stateless;

/**
 *
 * @author julien
 */

@Stateless
public class VoteResource {
    @javax.ejb.EJB
    private ArticleResourceSub articleResourceSub;
    @Context
    protected UriInfo uriInfo;
    protected EntityManager em;
    protected Long id;
  
    /** Creates a new instance of VoteResource */
    public VoteResource() {
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setEm(EntityManager em) {
        this.em = em;
    }

    /**
     * Get method for retrieving an instance of Vote identified by id in XML format.
     *
     * @param id identifier for the entity
     * @return an instance of VoteConverter
     */
    @GET
    @Produces({"application/xml", "application/json"})
    public VoteConverter get(@QueryParam("expandLevel")
                             @DefaultValue("1")
    int expandLevel) {
        return new VoteConverter(getEntity(), uriInfo.getAbsolutePath(), expandLevel);
    }

    /**
     * Put method for updating an instance of Vote identified by id using XML as the input format.
     *
     * @param id identifier for the entity
     * @param data an VoteConverter entity that is deserialized from a XML stream
     */
    @PUT
    @Consumes({"application/xml", "application/json"})
    public void put(VoteConverter data) {
        updateEntity(getEntity(), data.resolveEntity(em));
    }

    /**
     * Delete method for deleting an instance of Vote identified by id.
     *
     * @param id identifier for the entity
     */
    @DELETE
    public void delete() {
        deleteEntity(getEntity());
    }

    /**
     * Returns an instance of Vote identified by id.
     *
     * @param id identifier for the entity
     * @return an instance of Vote
     */
    protected Vote getEntity() {
        try {
            return (Vote) em.createQuery("SELECT e FROM Vote e where e.id = :id").setParameter("id", id).getSingleResult();
        } catch (NoResultException ex) {
            throw new WebApplicationException(new Throwable("Resource for " + uriInfo.getAbsolutePath() + " does not exist."), 404);
        }
    }

    /**
     * Updates entity using data from newEntity.
     *
     * @param entity the entity to update
     * @param newEntity the entity containing the new data
     * @return the updated entity
     */
    private Vote updateEntity(Vote entity, Vote newEntity) {
        Article article = entity.getArticle();
        Article articleNew = newEntity.getArticle();
        entity = em.merge(newEntity);
        if (article != null && !article.equals(articleNew)) {
            article.getVotes().remove(entity);
        }
        if (articleNew != null && !articleNew.equals(article)) {
            articleNew.getVotes().add(entity);
        }
        return entity;
    }

    /**
     * Deletes the entity.
     *
     * @param entity the entity to deletle
     */
    private void deleteEntity(Vote entity) {
        Article article = entity.getArticle();
        if (article != null) {
            article.getVotes().remove(entity);
        }
        em.remove(entity);
    }

    /**
     * Returns a dynamic instance of ArticleResource used for entity navigation.
     *
     * @param id identifier for the parent entity
     * @return an instance of ArticleResource
     */
    @Path("article/")
    public ArticleResource getArticleResource() {
        articleResourceSub.setParent(getEntity());
        return articleResourceSub;
    }

    @Stateless
    public static class ArticleResourceSub extends ArticleResource {

        private Vote parent;

        public void setParent(Vote parent) {
            this.parent = parent;
        }

        @Override
        protected Article getEntity() {
            Article entity = parent.getArticle();
            if (entity == null) {
                throw new WebApplicationException(new Throwable("Resource for " + uriInfo.getAbsolutePath() + " does not exist."), 404);
            }
            return entity;
        }
    }
}
