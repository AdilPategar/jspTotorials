/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.responcia.otn.articleevaluator.rest.converter;

import fr.responcia.otn.articleevaluator.Author;
import java.net.URI;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.ws.rs.core.UriBuilder;
import javax.persistence.EntityManager;
import java.util.List;
import fr.responcia.otn.articleevaluator.Article;

/**
 *
 * @author julien
 */

@XmlRootElement(name = "author")
public class AuthorConverter {
    private Author entity;
    private URI uri;
    private int expandLevel;
  
    /** Creates a new instance of AuthorConverter */
    public AuthorConverter() {
        entity = new Author();
    }

    /**
     * Creates a new instance of AuthorConverter.
     *
     * @param entity associated entity
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded@param isUriExtendable indicates whether the uri can be extended
     */
    public AuthorConverter(Author entity, URI uri, int expandLevel, boolean isUriExtendable) {
        this.entity = entity;
        this.uri = (isUriExtendable) ? UriBuilder.fromUri(uri).path(entity.getId() + "/").build() : uri;
        this.expandLevel = expandLevel;
        getArticles();
    }

    /**
     * Creates a new instance of AuthorConverter.
     *
     * @param entity associated entity
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded
     */
    public AuthorConverter(Author entity, URI uri, int expandLevel) {
        this(entity, uri, expandLevel, false);
    }

    /**
     * Getter for articles.
     *
     * @return value for articles
     */
    @XmlElement
    public ArticlesConverter getArticles() {
        if (expandLevel > 0) {
            if (entity.getArticles() != null) {
                return new ArticlesConverter(entity.getArticles(), uri.resolve("articles/"), expandLevel - 1);
            }
        }
        return null;
    }

    /**
     * Setter for articles.
     *
     * @param value the value to set
     */
    public void setArticles(ArticlesConverter value) {
        entity.setArticles((value != null) ? new java.util.ArrayList<Article>(value.getEntities()) : null);
    }

    /**
     * Getter for id.
     *
     * @return value for id
     */
    @XmlElement
    public Long getId() {
        return (expandLevel > 0) ? entity.getId() : null;
    }

    /**
     * Setter for id.
     *
     * @param value the value to set
     */
    public void setId(Long value) {
        entity.setId(value);
    }

    /**
     * Getter for firstName.
     *
     * @return value for firstName
     */
    @XmlElement
    public String getFirstName() {
        return (expandLevel > 0) ? entity.getFirstName() : null;
    }

    /**
     * Setter for firstName.
     *
     * @param value the value to set
     */
    public void setFirstName(String value) {
        entity.setFirstName(value);
    }

    /**
     * Getter for lastName.
     *
     * @return value for lastName
     */
    @XmlElement
    public String getLastName() {
        return (expandLevel > 0) ? entity.getLastName() : null;
    }

    /**
     * Setter for lastName.
     *
     * @param value the value to set
     */
    public void setLastName(String value) {
        entity.setLastName(value);
    }

    /**
     * Getter for url.
     *
     * @return value for url
     */
    @XmlElement
    public String getUrl() {
        return (expandLevel > 0) ? entity.getUrl() : null;
    }

    /**
     * Setter for url.
     *
     * @param value the value to set
     */
    public void setUrl(String value) {
        entity.setUrl(value);
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute
    public URI getUri() {
        return uri;
    }

    /**
     * Sets the URI for this reference converter.
     *
     */
    public void setUri(URI uri) {
        this.uri = uri;
    }

    /**
     * Returns the Author entity.
     *
     * @return an entity
     */
    @XmlTransient
    public Author getEntity() {
        if (entity.getId() == null) {
            AuthorConverter converter = UriResolver.getInstance().resolve(AuthorConverter.class, uri);
            if (converter != null) {
                entity = converter.getEntity();
            }
        }
        return entity;
    }

    /**
     * Returns the resolved Author entity.
     *
     * @return an resolved entity
     */
    public Author resolveEntity(EntityManager em) {
        List<Article> articles = entity.getArticles();
        List<Article> newarticles = new java.util.ArrayList<Article>();
        if (articles != null) {
            for (Article item : articles) {
                newarticles.add(em.getReference(Article.class, item.getId()));
            }
        }
        entity.setArticles(newarticles);
        return entity;
    }
}
