/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.responcia.otn.articleevaluator.rest.converter;

import fr.responcia.otn.articleevaluator.Article;
import java.net.URI;
import java.util.Collection;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;
import java.util.ArrayList;

/**
 *
 * @author julien
 */

@XmlRootElement(name = "articles")
public class ArticlesConverter {
    private Collection<Article> entities;
    private Collection<ArticleConverter> items;
    private URI uri;
    private int expandLevel;
  
    /** Creates a new instance of ArticlesConverter */
    public ArticlesConverter() {
    }

    /**
     * Creates a new instance of ArticlesConverter.
     *
     * @param entities associated entities
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded
     */
    public ArticlesConverter(Collection<Article> entities, URI uri, int expandLevel) {
        this.entities = entities;
        this.uri = uri;
        this.expandLevel = expandLevel;
        getArticle();
    }

    /**
     * Returns a collection of ArticleConverter.
     *
     * @return a collection of ArticleConverter
     */
    @XmlElement
    public Collection<ArticleConverter> getArticle() {
        if (items == null) {
            items = new ArrayList<ArticleConverter>();
        }
        if (entities != null) {
            items.clear();
            for (Article entity : entities) {
                items.add(new ArticleConverter(entity, uri, expandLevel, true));
            }
        }
        return items;
    }

    /**
     * Sets a collection of ArticleConverter.
     *
     * @param a collection of ArticleConverter to set
     */
    public void setArticle(Collection<ArticleConverter> items) {
        this.items = items;
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute
    public URI getUri() {
        return uri;
    }

    /**
     * Returns a collection Article entities.
     *
     * @return a collection of Article entities
     */
    @XmlTransient
    public Collection<Article> getEntities() {
        entities = new ArrayList<Article>();
        if (items != null) {
            for (ArticleConverter item : items) {
                entities.add(item.getEntity());
            }
        }
        return entities;
    }
}
