/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.responcia.otn.articleevaluator;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 *
 * @author julien
 */
@Stateless
public class ArticleFacade {
    @PersistenceContext(unitName = "ArticleEvaluatorPU")
    private EntityManager em;

    public void create(Article article) {
        em.persist(article);
    }

    public void edit(Article article) {
        em.merge(article);
    }

    public void remove(Article article) {
        em.remove(em.merge(article));
    }

    public Article find(Object id) {
        return em.find(Article.class, id);
    }

    public List<Article> findAll() {
        CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
        cq.select(cq.from(Article.class));
        return em.createQuery(cq).getResultList();
    }

    public List<Article> findRange(int[] range) {
        CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
        cq.select(cq.from(Article.class));
        Query q = em.createQuery(cq);
        q.setMaxResults(range[1] - range[0]);
        q.setFirstResult(range[0]);
        return q.getResultList();
    }

    public int count() {
        CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
        Root<Article> rt = cq.from(Article.class);
        cq.select(em.getCriteriaBuilder().count(rt));
        Query q = em.createQuery(cq);
        return ((Long) q.getSingleResult()).intValue();
    }

}
