/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.responcia.otn.articleevaluator.rest.converter;

import fr.responcia.otn.articleevaluator.Vote;
import java.net.URI;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.ws.rs.core.UriBuilder;
import javax.persistence.EntityManager;
import fr.responcia.otn.articleevaluator.Article;

/**
 *
 * @author julien
 */

@XmlRootElement(name = "vote")
public class VoteConverter {
    private Vote entity;
    private URI uri;
    private int expandLevel;
  
    /** Creates a new instance of VoteConverter */
    public VoteConverter() {
        entity = new Vote();
    }

    /**
     * Creates a new instance of VoteConverter.
     *
     * @param entity associated entity
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded@param isUriExtendable indicates whether the uri can be extended
     */
    public VoteConverter(Vote entity, URI uri, int expandLevel, boolean isUriExtendable) {
        this.entity = entity;
        this.uri = (isUriExtendable) ? UriBuilder.fromUri(uri).path(entity.getId() + "/").build() : uri;
        this.expandLevel = expandLevel;
        getArticle();
    }

    /**
     * Creates a new instance of VoteConverter.
     *
     * @param entity associated entity
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded
     */
    public VoteConverter(Vote entity, URI uri, int expandLevel) {
        this(entity, uri, expandLevel, false);
    }

    /**
     * Getter for id.
     *
     * @return value for id
     */
    @XmlElement
    public Long getId() {
        return (expandLevel > 0) ? entity.getId() : null;
    }

    /**
     * Setter for id.
     *
     * @param value the value to set
     */
    public void setId(Long value) {
        entity.setId(value);
    }

    /**
     * Getter for stars.
     *
     * @return value for stars
     */
    @XmlElement
    public Integer getStars() {
        return (expandLevel > 0) ? entity.getStars() : null;
    }

    /**
     * Setter for stars.
     *
     * @param value the value to set
     */
    public void setStars(Integer value) {
        entity.setStars(value);
    }

    /**
     * Getter for article.
     *
     * @return value for article
     */
    @XmlElement
    public ArticleConverter getArticle() {
        if (expandLevel > 0) {
            if (entity.getArticle() != null) {
                return new ArticleConverter(entity.getArticle(), uri.resolve("article/"), expandLevel - 1, false);
            }
        }
        return null;
    }

    /**
     * Setter for article.
     *
     * @param value the value to set
     */
    public void setArticle(ArticleConverter value) {
        entity.setArticle((value != null) ? value.getEntity() : null);
    }

    /**
     * Getter for ip.
     *
     * @return value for ip
     */
    @XmlElement
    public String getIp() {
        return (expandLevel > 0) ? entity.getIp() : null;
    }

    /**
     * Setter for ip.
     *
     * @param value the value to set
     */
    public void setIp(String value) {
        entity.setIp(value);
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute
    public URI getUri() {
        return uri;
    }

    /**
     * Sets the URI for this reference converter.
     *
     */
    public void setUri(URI uri) {
        this.uri = uri;
    }

    /**
     * Returns the Vote entity.
     *
     * @return an entity
     */
    @XmlTransient
    public Vote getEntity() {
        if (entity.getId() == null) {
            VoteConverter converter = UriResolver.getInstance().resolve(VoteConverter.class, uri);
            if (converter != null) {
                entity = converter.getEntity();
            }
        }
        return entity;
    }

    /**
     * Returns the resolved Vote entity.
     *
     * @return an resolved entity
     */
    public Vote resolveEntity(EntityManager em) {
        Article article = entity.getArticle();
        if (article != null) {
            entity.setArticle(em.getReference(Article.class, article.getId()));
        }
        return entity;
    }
}
