/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.responcia.otn.articleevaluator.rest.resource;

import fr.responcia.otn.articleevaluator.Author;
import java.util.Collection;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.persistence.EntityManager;
import fr.responcia.otn.articleevaluator.Article;
import fr.responcia.otn.articleevaluator.rest.converter.AuthorsConverter;
import fr.responcia.otn.articleevaluator.rest.converter.AuthorConverter;
import javax.persistence.PersistenceContext;
import javax.ejb.Stateless;

/**
 *
 * @author julien
 */

@Path("/authors/")
@Stateless
public class AuthorsResource {
    @javax.ejb.EJB
    private AuthorResource authorResource;
    @Context
    protected UriInfo uriInfo;
    @PersistenceContext(unitName = "ArticleEvaluatorPU")
    protected EntityManager em;
  
    /** Creates a new instance of AuthorsResource */
    public AuthorsResource() {
    }

    /**
     * Get method for retrieving a collection of Author instance in XML format.
     *
     * @return an instance of AuthorsConverter
     */
    @GET
    @Produces({"application/xml", "application/json"})
    public AuthorsConverter get(@QueryParam("start")
                                @DefaultValue("0")
    int start, @QueryParam("max")
               @DefaultValue("10")
    int max, @QueryParam("expandLevel")
             @DefaultValue("1")
    int expandLevel, @QueryParam("query")
                     @DefaultValue("SELECT e FROM Author e")
    String query) {
        return new AuthorsConverter(getEntities(start, max, query), uriInfo.getAbsolutePath(), expandLevel);
    }

    /**
     * Post method for creating an instance of Author using XML as the input format.
     *
     * @param data an AuthorConverter entity that is deserialized from an XML stream
     * @return an instance of AuthorConverter
     */
    @POST
    @Consumes({"application/xml", "application/json"})
    public Response post(AuthorConverter data) {
        Author entity = data.resolveEntity(em);
        createEntity(data.resolveEntity(em));
        return Response.created(uriInfo.getAbsolutePath().resolve(entity.getId() + "/")).build();
    }

    /**
     * Returns a dynamic instance of AuthorResource used for entity navigation.
     *
     * @return an instance of AuthorResource
     */
    @Path("{id}/")
    public AuthorResource getAuthorResource(@PathParam("id")
    Long id) {
        authorResource.setId(id);
        authorResource.setEm(em);
        return authorResource;
    }

    /**
     * Returns all the entities associated with this resource.
     *
     * @return a collection of Author instances
     */
    protected Collection<Author> getEntities(int start, int max, String query) {
        return em.createQuery(query).setFirstResult(start).setMaxResults(max).getResultList();
    }

    /**
     * Persist the given entity.
     *
     * @param entity the entity to persist
     */
    protected void createEntity(Author entity) {
        entity.setId(null);
        em.persist(entity);
        for (Article value : entity.getArticles()) {
            Author oldEntity = value.getAuthor();
            value.setAuthor(entity);
            if (oldEntity != null) {
                oldEntity.getArticles().remove(value);
            }
        }
    }
}
