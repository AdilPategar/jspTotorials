/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.responcia.otn.articleevaluator.rest.resource;

import fr.responcia.otn.articleevaluator.Vote;
import java.util.Collection;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.persistence.EntityManager;
import fr.responcia.otn.articleevaluator.Article;
import fr.responcia.otn.articleevaluator.rest.converter.VotesConverter;
import fr.responcia.otn.articleevaluator.rest.converter.VoteConverter;
import javax.persistence.PersistenceContext;
import javax.ejb.Stateless;

/**
 *
 * @author julien
 */

@Path("/votes/")
@Stateless
public class VotesResource {
    @javax.ejb.EJB
    private VoteResource voteResource;
    @Context
    protected UriInfo uriInfo;
    @PersistenceContext(unitName = "ArticleEvaluatorPU")
    protected EntityManager em;
  
    /** Creates a new instance of VotesResource */
    public VotesResource() {
    }

    /**
     * Get method for retrieving a collection of Vote instance in XML format.
     *
     * @return an instance of VotesConverter
     */
    @GET
    @Produces({"application/xml", "application/json"})
    public VotesConverter get(@QueryParam("start")
                              @DefaultValue("0")
    int start, @QueryParam("max")
               @DefaultValue("10")
    int max, @QueryParam("expandLevel")
             @DefaultValue("1")
    int expandLevel, @QueryParam("query")
                     @DefaultValue("SELECT e FROM Vote e")
    String query) {
        return new VotesConverter(getEntities(start, max, query), uriInfo.getAbsolutePath(), expandLevel);
    }

    /**
     * Post method for creating an instance of Vote using XML as the input format.
     *
     * @param data an VoteConverter entity that is deserialized from an XML stream
     * @return an instance of VoteConverter
     */
    @POST
    @Consumes({"application/xml", "application/json"})
    public Response post(VoteConverter data) {
        Vote entity = data.resolveEntity(em);
        createEntity(data.resolveEntity(em));
        return Response.created(uriInfo.getAbsolutePath().resolve(entity.getId() + "/")).build();
    }

    /**
     * Returns a dynamic instance of VoteResource used for entity navigation.
     *
     * @return an instance of VoteResource
     */
    @Path("{id}/")
    public VoteResource getVoteResource(@PathParam("id")
    Long id) {
        voteResource.setId(id);
        voteResource.setEm(em);
        return voteResource;
    }

    /**
     * Returns all the entities associated with this resource.
     *
     * @return a collection of Vote instances
     */
    protected Collection<Vote> getEntities(int start, int max, String query) {
        return em.createQuery(query).setFirstResult(start).setMaxResults(max).getResultList();
    }

    /**
     * Persist the given entity.
     *
     * @param entity the entity to persist
     */
    protected void createEntity(Vote entity) {
        entity.setId(null);
        em.persist(entity);
        Article article = entity.getArticle();
        if (article != null) {
            article.getVotes().add(entity);
        }
    }
}
