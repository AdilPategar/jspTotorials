/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.responcia.otn.articleevaluator.rest.converter;

import fr.responcia.otn.articleevaluator.Vote;
import java.net.URI;
import java.util.Collection;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;
import java.util.ArrayList;

/**
 *
 * @author julien
 */

@XmlRootElement(name = "votes")
public class VotesConverter {
    private Collection<Vote> entities;
    private Collection<VoteConverter> items;
    private URI uri;
    private int expandLevel;
  
    /** Creates a new instance of VotesConverter */
    public VotesConverter() {
    }

    /**
     * Creates a new instance of VotesConverter.
     *
     * @param entities associated entities
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded
     */
    public VotesConverter(Collection<Vote> entities, URI uri, int expandLevel) {
        this.entities = entities;
        this.uri = uri;
        this.expandLevel = expandLevel;
        getVote();
    }

    /**
     * Returns a collection of VoteConverter.
     *
     * @return a collection of VoteConverter
     */
    @XmlElement
    public Collection<VoteConverter> getVote() {
        if (items == null) {
            items = new ArrayList<VoteConverter>();
        }
        if (entities != null) {
            items.clear();
            for (Vote entity : entities) {
                items.add(new VoteConverter(entity, uri, expandLevel, true));
            }
        }
        return items;
    }

    /**
     * Sets a collection of VoteConverter.
     *
     * @param a collection of VoteConverter to set
     */
    public void setVote(Collection<VoteConverter> items) {
        this.items = items;
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute
    public URI getUri() {
        return uri;
    }

    /**
     * Returns a collection Vote entities.
     *
     * @return a collection of Vote entities
     */
    @XmlTransient
    public Collection<Vote> getEntities() {
        entities = new ArrayList<Vote>();
        if (items != null) {
            for (VoteConverter item : items) {
                entities.add(item.getEntity());
            }
        }
        return entities;
    }
}
