/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.responcia.otn.articleevaluator.rest.resource;

import fr.responcia.otn.articleevaluator.Article;
import java.util.Collection;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.QueryParam;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.WebApplicationException;
import javax.persistence.NoResultException;
import javax.persistence.EntityManager;
import fr.responcia.otn.articleevaluator.Vote;
import java.util.List;
import fr.responcia.otn.articleevaluator.Author;
import fr.responcia.otn.articleevaluator.rest.converter.ArticleConverter;
import javax.ejb.Stateless;

/**
 *
 * @author julien
 */

@Stateless
public class ArticleResource {
    @javax.ejb.EJB
    private AuthorResourceSub authorResourceSub;
    @javax.ejb.EJB
    private VotesResourceSub votesResourceSub;
    @Context
    protected UriInfo uriInfo;
    protected EntityManager em;
    protected Long id;
  
    /** Creates a new instance of ArticleResource */
    public ArticleResource() {
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setEm(EntityManager em) {
        this.em = em;
    }

    /**
     * Get method for retrieving an instance of Article identified by id in XML format.
     *
     * @param id identifier for the entity
     * @return an instance of ArticleConverter
     */
    @GET
    @Produces({"application/xml", "application/json"})
    public ArticleConverter get(@QueryParam("expandLevel")
                                @DefaultValue("1")
    int expandLevel) {
        return new ArticleConverter(getEntity(), uriInfo.getAbsolutePath(), expandLevel);
    }

    /**
     * Put method for updating an instance of Article identified by id using XML as the input format.
     *
     * @param id identifier for the entity
     * @param data an ArticleConverter entity that is deserialized from a XML stream
     */
    @PUT
    @Consumes({"application/xml", "application/json"})
    public void put(ArticleConverter data) {
        updateEntity(getEntity(), data.resolveEntity(em));
    }

    /**
     * Delete method for deleting an instance of Article identified by id.
     *
     * @param id identifier for the entity
     */
    @DELETE
    public void delete() {
        deleteEntity(getEntity());
    }

    /**
     * Returns an instance of Article identified by id.
     *
     * @param id identifier for the entity
     * @return an instance of Article
     */
    protected Article getEntity() {
        try {
            return (Article) em.createQuery("SELECT e FROM Article e where e.id = :id").setParameter("id", id).getSingleResult();
        } catch (NoResultException ex) {
            throw new WebApplicationException(new Throwable("Resource for " + uriInfo.getAbsolutePath() + " does not exist."), 404);
        }
    }

    /**
     * Updates entity using data from newEntity.
     *
     * @param entity the entity to update
     * @param newEntity the entity containing the new data
     * @return the updated entity
     */
    private Article updateEntity(Article entity, Article newEntity) {
        List<Vote> votes = entity.getVotes();
        List<Vote> votesNew = newEntity.getVotes();
        Author author = entity.getAuthor();
        Author authorNew = newEntity.getAuthor();
        entity = em.merge(newEntity);
        for (Vote value : votes) {
            if (!votesNew.contains(value)) {
                throw new WebApplicationException(new Throwable("Cannot remove items from votes"));
            }
        }
        for (Vote value : votesNew) {
            if (!votes.contains(value)) {
                Article oldEntity = value.getArticle();
                value.setArticle(entity);
                if (oldEntity != null && !oldEntity.equals(entity)) {
                    oldEntity.getVotes().remove(value);
                }
            }
        }
        if (author != null && !author.equals(authorNew)) {
            author.getArticles().remove(entity);
        }
        if (authorNew != null && !authorNew.equals(author)) {
            authorNew.getArticles().add(entity);
        }
        return entity;
    }

    /**
     * Deletes the entity.
     *
     * @param entity the entity to deletle
     */
    private void deleteEntity(Article entity) {
        if (!entity.getVotes().isEmpty()) {
            throw new WebApplicationException(new Throwable("Cannot delete entity because votes is not empty."));
        }
        Author author = entity.getAuthor();
        if (author != null) {
            author.getArticles().remove(entity);
        }
        em.remove(entity);
    }

    /**
     * Returns a dynamic instance of VotesResource used for entity navigation.
     *
     * @param id identifier for the parent entity
     * @return an instance of VotesResource
     */
    @Path("votes/")
    public VotesResource getVotesResource() {
        votesResourceSub.setParent(getEntity());
        return votesResourceSub;
    }

    /**
     * Returns a dynamic instance of AuthorResource used for entity navigation.
     *
     * @param id identifier for the parent entity
     * @return an instance of AuthorResource
     */
    @Path("author/")
    public AuthorResource getAuthorResource() {
        authorResourceSub.setParent(getEntity());
        return authorResourceSub;
    }

    @Stateless
    public static class VotesResourceSub extends VotesResource {

        private Article parent;

        public void setParent(Article parent) {
            this.parent = parent;
        }

        @Override
        protected Collection<Vote> getEntities(int start, int max, String query) {
            Collection<Vote> result = new java.util.ArrayList<Vote>();
            int index = 0;
            for (Vote e : parent.getVotes()) {
                if (index >= start && (index - start) < max) {
                    result.add(e);
                }
                index++;
            }
            return result;
        }
    }

    @Stateless
    public static class AuthorResourceSub extends AuthorResource {

        private Article parent;

        public void setParent(Article parent) {
            this.parent = parent;
        }

        @Override
        protected Author getEntity() {
            Author entity = parent.getAuthor();
            if (entity == null) {
                throw new WebApplicationException(new Throwable("Resource for " + uriInfo.getAbsolutePath() + " does not exist."), 404);
            }
            return entity;
        }
    }
}
