/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.responcia.otn.articleevaluator.rest.converter;

import fr.responcia.otn.articleevaluator.Article;
import java.net.URI;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.ws.rs.core.UriBuilder;
import javax.persistence.EntityManager;
import fr.responcia.otn.articleevaluator.Vote;
import java.util.List;
import fr.responcia.otn.articleevaluator.Author;

/**
 *
 * @author julien
 */

@XmlRootElement(name = "article")
public class ArticleConverter {
    private Article entity;
    private URI uri;
    private int expandLevel;
  
    /** Creates a new instance of ArticleConverter */
    public ArticleConverter() {
        entity = new Article();
    }

    /**
     * Creates a new instance of ArticleConverter.
     *
     * @param entity associated entity
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded@param isUriExtendable indicates whether the uri can be extended
     */
    public ArticleConverter(Article entity, URI uri, int expandLevel, boolean isUriExtendable) {
        this.entity = entity;
        this.uri = (isUriExtendable) ? UriBuilder.fromUri(uri).path(entity.getId() + "/").build() : uri;
        this.expandLevel = expandLevel;
        getVotes();
        getAuthor();
    }

    /**
     * Creates a new instance of ArticleConverter.
     *
     * @param entity associated entity
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded
     */
    public ArticleConverter(Article entity, URI uri, int expandLevel) {
        this(entity, uri, expandLevel, false);
    }

    /**
     * Getter for votes.
     *
     * @return value for votes
     */
    @XmlElement
    public VotesConverter getVotes() {
        if (expandLevel > 0) {
            if (entity.getVotes() != null) {
                return new VotesConverter(entity.getVotes(), uri.resolve("votes/"), expandLevel - 1);
            }
        }
        return null;
    }

    /**
     * Setter for votes.
     *
     * @param value the value to set
     */
    public void setVotes(VotesConverter value) {
        entity.setVotes((value != null) ? new java.util.ArrayList<Vote>(value.getEntities()) : null);
    }

    /**
     * Getter for id.
     *
     * @return value for id
     */
    @XmlElement
    public Long getId() {
        return (expandLevel > 0) ? entity.getId() : null;
    }

    /**
     * Setter for id.
     *
     * @param value the value to set
     */
    public void setId(Long value) {
        entity.setId(value);
    }

    /**
     * Getter for title.
     *
     * @return value for title
     */
    @XmlElement
    public String getTitle() {
        return (expandLevel > 0) ? entity.getTitle() : null;
    }

    /**
     * Setter for title.
     *
     * @param value the value to set
     */
    public void setTitle(String value) {
        entity.setTitle(value);
    }

    /**
     * Getter for text.
     *
     * @return value for text
     */
    @XmlElement
    public String getText() {
        return (expandLevel > 0) ? entity.getText() : null;
    }

    /**
     * Setter for text.
     *
     * @param value the value to set
     */
    public void setText(String value) {
        entity.setText(value);
    }

    /**
     * Getter for author.
     *
     * @return value for author
     */
    @XmlElement
    public AuthorConverter getAuthor() {
        if (expandLevel > 0) {
            if (entity.getAuthor() != null) {
                return new AuthorConverter(entity.getAuthor(), uri.resolve("author/"), expandLevel - 1, false);
            }
        }
        return null;
    }

    /**
     * Setter for author.
     *
     * @param value the value to set
     */
    public void setAuthor(AuthorConverter value) {
        entity.setAuthor((value != null) ? value.getEntity() : null);
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute
    public URI getUri() {
        return uri;
    }

    /**
     * Sets the URI for this reference converter.
     *
     */
    public void setUri(URI uri) {
        this.uri = uri;
    }

    /**
     * Returns the Article entity.
     *
     * @return an entity
     */
    @XmlTransient
    public Article getEntity() {
        if (entity.getId() == null) {
            ArticleConverter converter = UriResolver.getInstance().resolve(ArticleConverter.class, uri);
            if (converter != null) {
                entity = converter.getEntity();
            }
        }
        return entity;
    }

    /**
     * Returns the resolved Article entity.
     *
     * @return an resolved entity
     */
    public Article resolveEntity(EntityManager em) {
        List<Vote> votes = entity.getVotes();
        List<Vote> newvotes = new java.util.ArrayList<Vote>();
        if (votes != null) {
            for (Vote item : votes) {
                newvotes.add(em.getReference(Vote.class, item.getId()));
            }
        }
        entity.setVotes(newvotes);
        Author author = entity.getAuthor();
        if (author != null) {
            entity.setAuthor(em.getReference(Author.class, author.getId()));
        }
        return entity;
    }
}
