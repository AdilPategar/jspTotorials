/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.responcia.otn.articleevaluator.rest.converter;

import fr.responcia.otn.articleevaluator.Author;
import java.net.URI;
import java.util.Collection;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;
import java.util.ArrayList;

/**
 *
 * @author julien
 */

@XmlRootElement(name = "authors")
public class AuthorsConverter {
    private Collection<Author> entities;
    private Collection<AuthorConverter> items;
    private URI uri;
    private int expandLevel;
  
    /** Creates a new instance of AuthorsConverter */
    public AuthorsConverter() {
    }

    /**
     * Creates a new instance of AuthorsConverter.
     *
     * @param entities associated entities
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded
     */
    public AuthorsConverter(Collection<Author> entities, URI uri, int expandLevel) {
        this.entities = entities;
        this.uri = uri;
        this.expandLevel = expandLevel;
        getAuthor();
    }

    /**
     * Returns a collection of AuthorConverter.
     *
     * @return a collection of AuthorConverter
     */
    @XmlElement
    public Collection<AuthorConverter> getAuthor() {
        if (items == null) {
            items = new ArrayList<AuthorConverter>();
        }
        if (entities != null) {
            items.clear();
            for (Author entity : entities) {
                items.add(new AuthorConverter(entity, uri, expandLevel, true));
            }
        }
        return items;
    }

    /**
     * Sets a collection of AuthorConverter.
     *
     * @param a collection of AuthorConverter to set
     */
    public void setAuthor(Collection<AuthorConverter> items) {
        this.items = items;
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute
    public URI getUri() {
        return uri;
    }

    /**
     * Returns a collection Author entities.
     *
     * @return a collection of Author entities
     */
    @XmlTransient
    public Collection<Author> getEntities() {
        entities = new ArrayList<Author>();
        if (items != null) {
            for (AuthorConverter item : items) {
                entities.add(item.getEntity());
            }
        }
        return entities;
    }
}
