package fr.responcia.otn.articleevaluator.rest.resource;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Test class for the Article REST front-end.
 * @author Julien Dubois
 */
public class ArticleTest {

    private static final String url = "http://localhost:8080/ArticleEvaluator/resources/";

    @Test
    public void createArticle() throws Exception {
        HttpClient client = new HttpClient();
        client.getHttpConnectionManager().getParams().setConnectionTimeout(5000);
        PostMethod method = new PostMethod(url + "articles");
        String xml = "<article><title>Jersey Article</title><text>text</text></article>";
        RequestEntity requestEntity = new StringRequestEntity(xml, "application/xml", "UTF-8");
        method.setRequestEntity(requestEntity);
        client.executeMethod(method);
        String responseBody = method.getResponseBodyAsString();
        method.releaseConnection();
        assertEquals("", responseBody);
    }

    @Test
    public void testResourceAsXml() throws Exception {
        HttpClient client = new HttpClient();
        client.getHttpConnectionManager().getParams().setConnectionTimeout(5000);
        HttpMethod method = new GetMethod(url + "articles");
        client.executeMethod(method);
        String responseBody = method.getResponseBodyAsString();
        System.out.println(responseBody);
        method.releaseConnection();
        assertTrue(responseBody.contains("<title>Jersey Article</title>"));
    }

    @Test
    public void testResourceAsJson() throws Exception {
        HttpClient client = new HttpClient();
        client.getHttpConnectionManager().getParams().setConnectionTimeout(5000);
        HttpMethod method = new GetMethod(url + "articles");
        method.addRequestHeader("Accept", "application/json");
        client.executeMethod(method);
        String responseBody = method.getResponseBodyAsString();
        System.out.println(responseBody);
        method.releaseConnection();
        assertTrue(responseBody.contains("\"title\":\"Jersey Article\""));
    }
}
